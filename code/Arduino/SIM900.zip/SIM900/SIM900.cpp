#include <Arduino.h>
#include "SIM900.h"

#define _DEBUG_				1
#define _DEBUG_Pin			4

#define SIM_PWRKEY_PIN 		10
#define SIM_NRESET_PIN 		12

#define STT_OK		 		0
#define STT_EMPTY	 		1
#define STT_TIMEOUT 		2
#define STT_OVERFLOW 		3
#define STT_ERROR	 		4

extern void __delay_ms(unsigned long timeout);

//
// Constructor
//
SIM900::SIM900(void)
{
	buffer = new char[BUFFER_LEN];

#ifdef _DEBUG_
	pinMode(_DEBUG_Pin, OUTPUT);
#endif

	if(buffer == NULL)
	{
		while(1)
		{
#ifdef _DEBUG_
			digitalWrite(_DEBUG_Pin, LOW);
			__delay_ms(1000);
			digitalWrite(_DEBUG_Pin, HIGH);
			__delay_ms(1000);
#endif
		}
	}

	// Free SIM control pins
	pinMode(SIM_PWRKEY_PIN, INPUT);
	pinMode(SIM_NRESET_PIN, INPUT);
}

//
// Deconstructor
//
SIM900::~SIM900(void)
{
	// Free memory
	delete[] buffer;
}

void SIM900::init(char* pinNumber)
{
	uint8_t idx = 3;
	uint8_t retry = 0;
	boolean simPinNeeded = false;
	unsigned long baudrates [] = {115200, 57600, 38400, 19200, 9600, 4800, 2400, 1200};

	Serial.begin(9600);

	// SIM Power key pins
	pinMode(SIM_PWRKEY_PIN, OUTPUT);

	// Reset SIM Card
	digitalWrite(SIM_PWRKEY_PIN, HIGH); __delay_ms(1500);
	digitalWrite(SIM_PWRKEY_PIN, LOW);  __delay_ms(1500);

	while(1)
	{
		// Send AT every two seconds and wait for the answer
		answer = sendAtCommandAndCheckOK("AT",buffer, 1000);

		if(answer == STT_OK)
			break;

		if((retry++ > 2) && (idx < 8))
		{
			retry = 0;
			Serial.begin(baudrates[idx++]);
		}

		if(idx >= 8)
		{
			while(1)
			{
				// Module SIM900 is not responding!
#ifdef _DEBUG_
				digitalWrite(_DEBUG_Pin, LOW);
				__delay_ms(1000);
				digitalWrite(_DEBUG_Pin, HIGH);
				__delay_ms(1000);
#endif
			}
		}
	}

	/*
	 * ATE0 : command echo off
	 */
	sendAtCommandAndCheckOK("ATE0",buffer,500);
	
	/*
	 * set auto baud
	 */
	//sendAtCommandAndCheckOK("AT+IPR?",buffer,500);
	// sendAtCommandAndCheckOK("AT+IPR=0",buffer,500);
	
	/*
	 * Check phone functionnality
	 */
	// answer = sendAtCommandAndCheckOK("AT+CFUN?",buffer,500);

	// if((answer == STT_OK) && (strstr(buffer,"+CFUN: 1") == NULL))
	// {
	// 	sendAtCommandAndCheckOK("AT+CFUN=1,1",buffer,10000);
	// }
	
	/*
	 * Check PIN input need
	 */
	// if(pinNumber != NULL){
	// 	answer = sendAtCommandAndCheckOK("AT+CPIN?",buffer,500);
	// 	if(answer == STT_OK && strstr(buffer,"+CPIN: SIM PIN")!=NULL){
	// 		sprintf(buffer,"AT+CPIN=%s", pinNumber);
	// 		answer = sendAtCommandAndCheckOK(buffer,buffer,  500);
	// 		if(answer>STT_OK) return;
	// 	}
	// }

	/*
	 * Mode texte
	 */	
	sendAtCommandAndCheckOK("AT+CMGF=1",buffer,500);    // sets the SMS mode to text

	// Disable messages about new SMS from the GSM module
	sendAtCommandAndCheckOK("AT+CNMI=2,0", buffer, 1000);

	// send AT command to init memory for SMS in the SIM card
	sendAtCommandAndCheckOK("AT+CPMS=\"SM\",\"SM\",\"SM\"", buffer, 1000);
}

/*
 * Envoi une command AT au SIM900, et vérifie que la réponse contient la chaine attendue ()
 * Attend jusqu'au timeout.
 * Réponse : 
 *    0:OK - response match
 *    1:Empty
 *    2:Timeout
 *    3:Overflow
 *    4:Response does not match
 */
uint8_t SIM900::sendAtCommandAndCheckOK(char* command, char* response, unsigned int timeout)
{
	 sendAtCommand(command);
	 return checkOK(response, timeout);
}

/*
 * Envoi une command AT au SIM900
 */
void SIM900::sendAtCommand(char* command)
{
	char ch;
	
	__delay_ms(50);

	while(Serial.available())
		Serial.read();
	
	Serial.flush();

	Serial.println(command);
}

/*
 * Attend et vérifie que la réponse contient la chaine attendue
 * Attend jusqu'au timeout.
 * Réponse : 
 *    0:OK - response match
 *    1:Empty
 *    2:Timeout
 *    3:Overflow
 *    4:ERROR
 */
uint8_t SIM900::checkOK(char* response, unsigned int timeout)
{
	// char* sub;
	uint16_t idx;
	
	// The answer eventually starts with an "echo" of the request, and then a blank line
	// Ignore the first part
	if(answer = readLine(response, timeout, false) == STT_TIMEOUT)
		return answer;

	if(answer = readLine(response, timeout, false) == STT_TIMEOUT)
		return answer;
	
	while((answer == STT_OK) || (answer == STT_EMPTY))
	{
		// We look at whether the response ends with OK
		// sub = strstr(response,"\r\nOK");
		idx = strlen(response) - 6;

		if((idx >= 0) && (strstr(&response[idx],"\r\nOK\r\n") != NULL))
		{
			// Reponse OK
			// We truncate the buffer to remove "OK"
			response[idx] = '\0';
			break;
		}

		// We look at whether the response begins with OK
		if(strstr(response, "OK") != NULL)
		{
			break;
		}
		
		// We look at whether the response begins or ends with "ERROR"
		idx = strlen(response) - 9;

		//if(strcmp("ERROR",response)<0 || idx>=0 && strcmp(&response[idx],"\r\nERROR\r\n") == 0)
		if((idx >= 0) && (strstr(&response[idx],"\r\nERROR\r\n") != NULL))
		{
			// Reponse ERROR
			answer = STT_ERROR;
			break;
		}

		// We read the following lines until you have the expected response
		answer = readLine(response, timeout, true);
	}
	
	// if(answer == STT_ERROR) 
	// 	debugLastError();
	
	return answer;
}

void SIM900::debugLastError()
{
	// textual error message
	sendAtCommandAndCheckOK("AT+CEER=0",buffer,500);
	sendAtCommandAndCheckOK("AT+CEER",buffer,500); 
}

/*
 * Lit une ligne en provenance du SIM900
 * Attend jusqu'au timeout.
 * Réponse : 
 *    0:OK
 *    1:Empty
 *    2:Timeout
 *    3:Overflow
 *
 */
uint8_t SIM900::readLine(char* response, unsigned int timeout, boolean append)
{
	char ch;
	uint8_t idx = 0;

	answer = STT_TIMEOUT;  			// Timeout default

	if(append)
	{
		idx = strlen(response);
	}
	else
	{
		// Fill buffer with NULL character
		memset(response, '\0', BUFFER_LEN - 1);
	}
	
	while(timeout--)
	{
		__delay_ms(1);

		while(Serial.available())
		{
			ch = (char)Serial.read();
			
			// check that it fits in the buffer
			if((idx + 1) >= BUFFER_LEN)
			{
				return STT_OVERFLOW;
			}

			response[idx++] = ch;

			if(ch == '\n')
			{
				answer = STT_OK;

				if(idx <= 2)
					answer = STT_EMPTY;

				return answer;
			}
		}		
	}

	return answer;
}

/*
 * Attend jusqu'au timeout l'invite ">" de la part de la SIM
 * Réponse : 
 *    0:OK
 *    2:Timeout
 */
uint8_t SIM900::waitPrompt(unsigned int timeout)
{
	char ch;
	uint8_t idx = 0;
	
	answer = STT_TIMEOUT;
	
	while(timeout--)
	{
		__delay_ms(1);

		while(Serial.available())
		{
			ch = (char)Serial.read();
			
			if(ch == '>')
			{
				return STT_OK;
			}
		}
	}	 
	return answer;
}

/*
 * 	Send a SMS to phone number
 */
uint8_t SIM900::sendSMS(char* phoneNumber, char* msg)
{
	// Set the SMS mode to text
	sendAtCommandAndCheckOK("AT+CMGF=1", buffer, 500);

	// Preapare phone recipient number
	sprintf(buffer,"AT+CMGS=\"%s\"", phoneNumber);

	sendAtCommand(buffer);

	answer = waitPrompt(2000);
	
	if(answer == STT_OK)
	{
		Serial.println(msg);
		Serial.write((byte)0x1A);

		// Expected response
		answer = checkOK(buffer, 10000);
	}

	__delay_ms(10);
	
	return answer;
}

/*
 * SMS read
 * Answer: 
 * 		msg 	: SMS message
 * 		NULL 	: Read Error
 */
char* SIM900::readSMS(uint8_t smsIdx, char* num_tel, unsigned int timeout)
{
	char *tmp, *msg;
	char *stat, *tel;
	char cmd[15];

	// Null terminal string
	*num_tel = '\0';
	memset(buffer, '\0', BUFFER_LEN-1);

	sprintf((char*)cmd,"AT+CMGR=%d", smsIdx);

	// Gets the # smsIdx SMS
	answer = sendAtCommandAndCheckOK((char*)cmd, buffer, timeout);

	// Default return value
	msg = NULL;

	if((strlen(buffer) <= 4) || (answer != STT_OK))
		return NULL;

	if(strstr(buffer, "+CMGR:") != NULL)
	{
		tmp = strchr(buffer + 2, '\n');		// Find <LF>
		msg = tmp + 1;						// Point to message contents
		*tmp = '\0';						// End of message header
		
		// Parse data from message header
		strtok(buffer, "\"");               //1° token : +CMGR:
		stat = strtok(NULL, "\"");    		//2° token : REC UNREAD ou REC READ

		strtok(NULL, "\"");                 //3° token : ","
		tel = strtok(NULL, "\"");     		//4° token : phone number
		
		if(num_tel != NULL)
			strcpy(num_tel, tel);
	}

	return msg;
}

/*
 *	Delete a SMS
 */
uint8_t SIM900::deleteSMS(uint8_t smsIdx)
{
	char cmd[15];	

	sprintf((char*)cmd, "AT+CMGD=%d", smsIdx);

	answer = sendAtCommandAndCheckOK((char*)cmd, buffer, 500);

	return answer;
}

/*
 * Is it is registered with the network?
 */
boolean SIM900::isRegistered()
{
	answer = sendAtCommandAndCheckOK("AT+CREG?", buffer,  500);

	if((answer == STT_OK) && ((strstr(buffer,"+CREG: 0,1") != NULL) || (strstr(buffer,"+CREG: 0,5") != NULL)))
		return true;
	else 
		return false;
}

/*
 * 	Call phone number
 */
uint8_t SIM900::call(char* phoneNumber)
{
	char *cmd[20];

	sprintf((char*)cmd, "ATD%s;", phoneNumber);

	// answer = sendAtCommandAndCheckOK((char*)cmd, buffer, 1500);

	sendAtCommand((char*)cmd);
	__delay_ms(500);

	return answer;
}

/*
 * 	Read account from *101#
 */
uint16_t SIM900::readMoneyAccount(void)
{
	int i, data, money;
	char strResponse[200];
	char strBegin[14] = "TK goc la ";
	char strEnd[7] = "dong.";
	char *p1, *p2;

	i = 0;
	
	while(Serial.available())
		Serial.read();

	Serial.flush();

	call("*101#");

	while(1)
	{
		while(Serial.available())
		{
			strResponse[i++] += (char)Serial.read();
			strResponse[i] = 0;
		}

		// Find end of data
		p1 = strstr((char *)strResponse, (char*)strEnd);

		// Found
		if(p1 != NULL)
			break;
	}

	p1 = strstr((char *)strResponse, (char*)strBegin) + 12;
	p2 = strstr((char *)strResponse, (char*)strEnd) - 1;

	// Set end of string at this point
	*p2 = 0;
	
	// Money data is now contains in p1
	money = atoi(p1);
	return money;
}