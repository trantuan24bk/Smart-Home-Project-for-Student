#ifndef SIM900_h
#define SIM900_h

#include <Arduino.h>

#define BUFFER_LEN 200

class SIM900
{
public:
	SIM900(void);
	~SIM900(void);
	
	void init(char* pinNumber);
	
	void 	sendAtCommand(char* command);
	uint8_t sendAtCommandAndCheckOK(char* command, char* response, unsigned int timeout);
	uint8_t checkOK(char* response, unsigned int timeout);
	uint8_t sendSMS(char* phoneNumber,char* msg);
	char* 	readSMS(uint8_t smsIdx, char* num_tel, unsigned int timeout);
	uint8_t deleteSMS(uint8_t smsIdx);
	boolean isRegistered();
	void 	debugLastError();

	uint8_t call(char* phoneNumber);
	uint16_t readMoneyAccount(void);

protected:
	uint8_t waitPrompt(unsigned int timeout);
	uint8_t readLine(char* response, unsigned int timeout, boolean append);

private:
	char* buffer;
	uint8_t answer;
};

#endif
